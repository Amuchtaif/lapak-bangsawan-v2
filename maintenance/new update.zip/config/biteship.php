<?php
// Biteship API Configuration
// URL Testing: https://api.biteship.com/v1
// Documentation: https://api.biteship.com

define('BITESHIP_API_KEY', 'biteship_test.eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJuYW1lIjoibGFwYWstaW50ZWdyYXNpIiwidXNlcklkIjoiNjk3MzNmNGQzODI5ZDI2YmNiMzNlM2Q4IiwiaWF0IjoxNzY5NDg3OTUxfQ.7O5smgSFozNbLObYHe6qXA4kvNhK-7lI4vC2Tn4hxSA');
define('BITESHIP_BASE_URL', 'https://api.biteship.com/v1');

// You can also add default origin area ID if you have it
define('BITESHIP_ORIGIN_AREA_ID', 'IDNP9IDNC105IDND171IDZ45171'); // Example ID for a specific area
define('BITESHIP_ORIGIN_LAT', -6.744815286779071); // Origin Latitude for Instant Courier
define('BITESHIP_ORIGIN_LNG', 108.53552144352373); // Origin Longitude for Instant Courier