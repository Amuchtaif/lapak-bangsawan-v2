<?php
require_once 'config/init.php';
header("Location: " . BASE_URL . "public/home");
exit;
?>
