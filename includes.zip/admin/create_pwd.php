<?php
$password = 'th1f4npokh4n'; // ganti dengan password kamu
echo password_hash($password, PASSWORD_DEFAULT);
