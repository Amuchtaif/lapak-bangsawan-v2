<?php
require_once 'config/init.php';
header("Location: " . BASE_URL . "home");
exit;
?>