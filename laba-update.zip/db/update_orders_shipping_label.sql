ALTER TABLE `orders` ADD COLUMN `shipping_label_url` TEXT NULL AFTER `tracking_id`;
