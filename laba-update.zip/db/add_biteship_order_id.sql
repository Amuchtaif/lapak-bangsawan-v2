ALTER TABLE orders ADD COLUMN biteship_order_id VARCHAR(50) NULL AFTER order_token;
